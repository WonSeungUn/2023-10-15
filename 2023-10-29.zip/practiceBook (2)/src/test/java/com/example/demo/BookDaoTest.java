package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;
import org.springframework.transaction.annotation.*;

import com.example.demo.dao.book.*;
import com.example.demo.entity.book.*;

@SpringBootTest
public class BookDaoTest {
	@Autowired
	private BookDao bookDao;


//	@Test
//	@Transactional
	public void deleteTest() {
		assertEquals(1, bookDao.deleteById(86L));
	}
	
	@Test
	@Transactional
	public void test() {
		Book book = bookDao.findByBno(86L);
		book.setBookIntro("안녕");
		
		Long update = bookDao.bookUpdate(book);
		assertEquals(1L, update);
	}
	
	@Test
	public void saveTest() {
		
	}
	
}
