
package com.example.demo.dao.book;

import java.util.*;

import org.apache.ibatis.annotations.*;

import com.example.demo.dto.book.*;
import com.example.demo.entity.book.*;

@Mapper
public interface BookDao {
	// 셀렉트키 활용
	@SelectKey(statement = "select book_seq.nextval from dual", before = true, resultType = long.class, keyProperty = "bno")

	// 책 등록 → 2023/10/11 (원승언 수정)
	@Insert("INSERT INTO book (bno, category_code, book_title, book_image, book_intro, book_content, publish_date, book_price, stock, translator, publisher_name, author_name) "
			+ "VALUES (#{bno}, #{categoryCode}, #{bookTitle}, #{bookImage}, #{bookIntro}, #{bookContent}, #{publishDate}, #{bookPrice}, #{stock}, #{translator}, #{publisherName}, #{authorName})")
	public Integer save(Book book);

	// 도서 페이지 (최근 5권의 소설, 참고도서, 만화를 선택해서 리스트 보여주기) (book-mapper에 있음)
	public List<BookDto.Recent> find5Recent(Long categoryParent, String memberId, Long gradeCode);
	
	// 책 정보 가져오기 (book-mapper에 있음)
	public Book findByBook(Long bno, String memberId, Long gradeCode);
	
	// 주어진 책 번호에 해당하는 책의 카테고리 코드를 반환
	@Select("SELECT category_code FROM book WHERE bno = #{bno} and rownum = 1")
	public Long findCategoryCodeByBno(Long bno);
	
	// 작가의 다른 작품 가져오기 (book-mapper에 있음)
	public List<Book> findOtherBooksByAuthor(String authorName);
	
	// 작품 종류별로 페이징해서 가지고 오기 (book-mapper에 있음)
	public List<BookDto.CategoryParentList> findBookByCategoryParent(Long categoryParent, String memberId, Long gradeCode, Long startRownum, Long endRownum); 
	
	// 작품 장르별로 페이징해서 가지고 오기 (book-mapper에 있음)
	public List<BookDto.CategoryCodeList> findBookByCategoryCode(Long categoryCode, Long categoryParent, String memberId, Long gradeCode, Long startRownum, Long endRownum);
	
	// 작품 종류별로 총 개수 구하기
	@Select("select count(*) from book inner join category on book.category_code=category.category_code where category.category_parent = #{categoryParent}")
	public Long categoryParentCount(Long categoryParent);
	
	// 작품 장르별로 총 개수 구하기
	@Select("select count(*) from book inner join category on book.category_code=category.category_code where category.category_code = #{categorycode}")
	public Long categoryCodeCount(Long categoryCode);


	// 북 삭제
	@Delete("delete from book where bno=#{bno}")
	public Long deleteById(Long bno);

	// 장바구니 상품 개수를 증가할 때 재고량을 확인하기 위해 사용한다
	@Select("select stock from book where bno=#{bno} and rownum=1")
	public Long findStockById(Long bno);

//  도서 업데이트
	@Update("update book set book_title=#{bookTitle}, sub_title=#{subTitle}, book_price=#{bookPrice}"
			+ ", translator=#{translator} where bno=#{bno}")
	public Long updateBook(Long bno);

}
