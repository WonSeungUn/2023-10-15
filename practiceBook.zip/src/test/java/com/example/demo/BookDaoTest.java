package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;

import java.time.*;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;
import org.springframework.transaction.annotation.*;

import com.example.demo.dao.book.*;
import com.example.demo.entity.book.*;

@SpringBootTest
public class BookDaoTest {
	@Autowired
	private BookDao bookDao;

//	@Test
	public void savetest() {
		for (int i = 1; i < 21; i++) {
		    String category;
		    String bookTitle;
		    Long categoryCode;

		    if (i % 3 == 0) {
		        category = "중/고등참고서";
		        categoryCode = 131L;
		        bookTitle = "중/고등참고서" + "[" + i + "]";
		    } else if(i % 3 == 1) {
		    	category = "토익교재";
		        categoryCode = 132L;
		        bookTitle = "토익교재" + "[" + i + "]";
		    }  else {
		        category = "EBS교재";
		        categoryCode = 133L;
		        bookTitle = "EBS교재" + "[" + i + "]";
		    }

		    Book book = new Book(
		        null, // ID를 제공하거나 자동 생성되는 경우 null로 설정할 수 있습니다.
		        categoryCode, // 카테고리 코드 
		        bookTitle,
		        "textBook.jpg", // 이미지 파일 이름
		        category.toLowerCase() + " 참고 도서입니다.",
		        bookTitle + "에 대한 책 설명",
		        LocalDate.of(2023, 9, 10),
		        12000L, // 가격
		        20L, // 재고
		        "", // 다른 속성
		        "출판사",
		        "원승언"
		    );

		    assertEquals(bookDao.save(book), 1);
		}

			
	}
	
	@Test
	@Transactional
	public void find5RecentTest() {
		assertEquals(5,bookDao.find5Recent(120L, "spring", 1L).size() );
	}
	
//	@Test
	public void deleteTest() {
		assertEquals(1, bookDao.deleteById(2L));
	}
}
