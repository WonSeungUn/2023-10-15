package com.example.demo.dto.book;

import java.util.*;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuthorNameListPage {
	private Long prev;
	private Long start;
	private Long end;
	private Long next;
	private Long pageno;
	private String keyword;
	private List<BookDto.BookList> books;
}


/*
 * 2023 - 10 - 20 (feat. 원승언)
 * 작가 이름을 통해 작가의 도서 정보를 나열하여 목록을 만들어주는 페이지 
 */