package com.example.demo.dto.book;

import java.time.*;

import org.springframework.format.annotation.*;
import org.springframework.web.multipart.*;

import com.example.demo.entity.book.*;

import lombok.*;

@NoArgsConstructor(access=AccessLevel.PRIVATE)
public class BookDto {
	@Data
	public static class Add {
		private Long categoryCode;
		private String bookTitle;
		private MultipartFile bookImage;
		private String bookIntro; 
		private String bookContent; 
		@DateTimeFormat(pattern = "yyyy-MM-dd")
		private LocalDate publishDate;
		private Long bookPrice;
		private Long stock;
		private String translator;
		private String publisherName;	
		private String authorName;	
		
		public Book toEntity(String defaultbookImage) {
			return new Book(null, categoryCode, bookTitle, defaultbookImage, bookIntro, bookContent, publishDate, bookPrice, stock, translator
					, publisherName, authorName);
		}
	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	public static class Recent {
		private Long bno;
		private String bookTitle;
		private String bookImage;
		private String authorName;
		private String publisherName;
		private Long bookPrice;
		private Long categoryParent;
		private String memberId;
		private Long gradeCode;
		private Double pointRate;
		private Long pointEarnings;
	}
	
	
}







