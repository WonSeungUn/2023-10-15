package com.example.demo;

 
import org.springframework.beans.factory.annotation.*;
import org.springframework.context.annotation.*;
import org.springframework.security.config.annotation.method.configuration.*;
import org.springframework.security.config.annotation.web.builders.*;
import org.springframework.security.config.annotation.web.configuration.*;
import org.springframework.security.web.*;
import org.springframework.security.web.access.*;

// SecurityConfig는 스프링 시큐리티를 위한 설정 파일
// 1. @Enablerity : 어노테이션(PreAuthrize, Secured) 기반 설정을 활성화
// 3. 로그인에 대한 설정 : 로그인 주소, 로그인 처리 주소, 로그인 후 이동할 주소, 로그인 실패 후 이동할 주소
// 4. 로그아웃 설정 : 로그아웃 주소, 로그아웃 후 이동할 주소
// 5. 403 예외를 처리할 AccessDeniedHandler 등록

@EnableMethodSecurity(prePostEnabled=true, securedEnabled=true)
@EnableWebSecurity
@Configuration
public class SecurityConfig {
	@Autowired
	private AccessDeniedHandler accessDeniedHandler;
	
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http.csrf().disable();
		http.formLogin().loginPage("/login")
			.loginProcessingUrl("/login")
			.defaultSuccessUrl("/")
			.failureUrl("/login?error");
		http.logout().logoutUrl("/logout").logoutSuccessUrl("/");
		http.exceptionHandling().accessDeniedHandler(accessDeniedHandler);
		return http.build();
	}
}




