package com.example.demo.controller.book;

import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;

import javax.servlet.http.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;

import com.example.demo.dto.book.*;
import com.example.demo.service.book.*;

import lombok.extern.slf4j.*;


@Slf4j
@Controller
public class BookController {
	@Autowired
	private BookService service;
	
	// 1. 상품 종류별로 5개씩 리스트 보여주는 페이지(도서페이지)
	
	@GetMapping("/category/book")
	public ModelAndView showCategoryBook(HttpServletRequest request) {
	    ModelAndView modelAndView = new ModelAndView("/category/book");

	    // 세션에서 사용자 정보 가져오기
	    HttpSession session = request.getSession();
	    String memberId = (String) session.getAttribute("memberId");
	    Long gradeCode = (Long) session.getAttribute("gradeCode");

	    // Principal을 통한 대체
	    Principal principal = request.getUserPrincipal();
	    if (principal != null) {
	        memberId = principal.getName();  // Principal의 이름을 memberId로 사용
	        // 추가적인 사용자 정보를 가져와서 gradeCode 등 필요한 값들을 설정할 수 있습니다.
	        // ...
	    } else {
	        memberId = "0";  // 비회원인 경우 기본값으로 설정
	        gradeCode = 0L;
	    }

	    // 도서 목록 가져오기
	    List<BookDto.Recent> novelBooks = service.get5RecentBooks(110L, gradeCode, memberId);
	    List<BookDto.Recent> comicBooks = service.get5RecentBooks(120L, gradeCode, memberId);
	    List<BookDto.Recent> textBooks = service.get5RecentBooks(130L, gradeCode, memberId);

	  	// 포인트 적립 (회원인 경우에만)
	  	if (!"0".equals(memberId)) {
	      	for (BookDto.Recent book : novelBooks) {
	          	Double pointRate = book.getPointRate();
	          	Long bookPrice = book.getBookPrice();
	          	Long pointEarnings = Math.round(bookPrice * pointRate);
	          	book.setPointEarnings(pointEarnings);
	      	}
	      	for (BookDto.Recent book : comicBooks) {
	          	Double pointRate = book.getPointRate();
	          	Long bookPrice = book.getBookPrice();
	          	Long pointEarnings= Math.round(bookPrice * pointRate);
	         	book.setPointEarnings(pointEarnings);
	     	}
	     	for (BookDto.Recent book : textBooks) {
	         	Double pointRate=book.getPointRate();
	         	Long bookPrice=book.getBookPrice();
	         	Long pointEarnings=Math.round(bookPrice *pointRate);
	         	book.setPointEarnings(pointEarnings); 
	      }
	   }

	  	modelAndView.addObject("novelBooks", novelBooks);
	  	modelAndView.addObject("comicBooks", comicBooks);
	  	modelAndView.addObject("textBooks", textBooks);

	     return modelAndView;
	}



	
	
	@GetMapping("/category/{imageName}")
	public ResponseEntity<byte[]> viewProfile(@PathVariable String imageName) {
	  File file = new File("c:/upload/books", imageName);
	  try {
		byte[] bytes = Files.readAllBytes(file.toPath());
		String contentType = Files.probeContentType(file.toPath()); 
		MediaType type = MediaType.parseMediaType(contentType);
		return ResponseEntity.ok().contentType(type).body(bytes);
	  } catch(Exception e) {
		  e.printStackTrace();
	  }
	  return null;
	}
}
