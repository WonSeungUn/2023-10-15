package com.example.demo.controller.book;

import org.springframework.beans.factory.annotation.*;
import org.springframework.security.access.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;

import com.example.demo.dto.book.*;
import com.example.demo.service.book.*;

// 상품 추가, 삭제
// 작업을 하려면 ADMIN 권한이 필요하므로 작성자 아이디를 확인하지 않는다

@Secured("ROLE_ADMIN")
@Controller
public class BookAdminController {
	@Autowired
	private BookAdminService service;
	
	// 1-1. 상품 추가 페이지(GetMapping)
	@GetMapping("/admin/book/add")
	public ModelAndView add() {
		return new ModelAndView("admin_product_add_page");
	}
	
	// 1-2. 상품 추가 페이지(PostMapping)
	@PostMapping("/admin/book/add")
	public ModelAndView add(BookDto.Add dto) {
		service.add(dto);
		return new ModelAndView("redirect:/");
	}
	
	// 2-1. 관리자 상품 리스트 페이지(GetMapping)
	@GetMapping("/admin/book/list")
	public ModelAndView adminBookList(@RequestParam(defaultValue = "1") Long pageno) {
		Page page = service.adminBookList(pageno);
		return new ModelAndView("admin_product_list_page").addObject("page", page);
	}
	
}
