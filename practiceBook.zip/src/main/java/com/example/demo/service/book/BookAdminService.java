package com.example.demo.service.book;

import java.io.*;
import java.nio.file.*;
import java.util.*;

import org.apache.commons.io.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.web.multipart.*;

import com.example.demo.dao.book.*;
import com.example.demo.dto.book.*;
import com.example.demo.entity.book.*;

@Service
public class BookAdminService {
	@Autowired
	private BookDao bookDao;

	@Value("${numberOfProductsPerPage}")
	private Long numberOfProductsPerPage;

	@Value("${sizeOfPagination}")
	private Long sizeOfPagination;

	@Value("${bookImageFolder}")
	private String imageFolder;

	@Value("${bookImageUrl}")
	private String imageUrl;

	@Value("${defaultBookImage}")
	private String defaultBookImage;

	// 1. 상품 등록 Service
	public Boolean add(BookDto.Add dto) {
		MultipartFile bookImage = dto.getBookImage();
		String imageName = defaultBookImage;

		// 사용자가 사진을 등록한 경우
		if (!bookImage.isEmpty()) {
			String extension = FilenameUtils.getExtension(bookImage.getOriginalFilename());
			imageName = dto.getAuthorName() + "_" + dto.getBookTitle() + "." + extension;
			// 폴더에 파일명을 주고 파일 객체를 생성 -> 0바이트 파일 생성
			File file = new File(imageFolder, imageName);
			// profile의 내용을 file로 이동시키자
			try {
				bookImage.transferTo(file);
			} catch (IllegalStateException | IOException e) {
				e.printStackTrace();
			}
		} else {
			// 사용자가 사진을 등록하지 않은 경우
			File image = new File(imageFolder, defaultBookImage);
			imageName = dto.getAuthorName() + "_" + dto.getBookTitle() + "." + "png";

			if (image.exists()) {
				File file = new File(imageFolder, imageName);
				try {
					Files.copy(image.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

		Book b = dto.toEntity(imageName);
		return bookDao.save(b) == 1;

	}

	// 2. 도서 관리를 위한 도서 리스트
	public Page adminBookList(Long pageno) {
		Long count = bookDao.adminBookListCount();
		Long numberOfPage = (count - 1) / numberOfProductsPerPage + 1;

		Long startRownum = (pageno - 1) * numberOfProductsPerPage + 1;
		Long endRownum = pageno * numberOfProductsPerPage;
		List<Book> products = bookDao.findAll(startRownum, endRownum);

		Long start = (pageno - 1) / sizeOfPagination * sizeOfPagination + 1;
		Long prev = start - 1;
		Long end = prev + sizeOfPagination;
		Long next = end + 1;

		// end가 numberOfPage보다 같거나 크다면...처리
		if (end >= numberOfPage) {
			end = numberOfPage;
			next = 0L;
		}
		return new Page(prev, start, end, next, pageno, products);
	}

}
