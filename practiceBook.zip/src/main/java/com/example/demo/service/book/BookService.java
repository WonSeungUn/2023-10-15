package com.example.demo.service.book;

import java.io.*;
import java.nio.file.*;
import java.util.*;

import org.apache.commons.io.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.web.multipart.*;

import com.example.demo.dao.book.*;
import com.example.demo.dao.member.*;
import com.example.demo.dto.book.*;
import com.example.demo.entity.book.*;
import com.example.demo.entity.member.*;

@Service
public class BookService {
	@Autowired
	private BookDao bookDao;
	
	@Autowired
	private MemberDao memberDao;

	@Value("${numberOfProductsPerPage}")
	private Long numberOfProductsPerPage;

	@Value("${sizeOfPagination}")
	private Long sizeOfPagination;

	@Value("${bookImageFolder}")
	private String imageFolder;

	@Value("${bookImageUrl}")
	private String imageUrl;

	@Value("${defaultBookImage}")
	private String defaultBookImage;

	// 1. 상품 등록 Service
	public Boolean add(BookDto.Add dto) {
		MultipartFile bookImage = dto.getBookImage();
		String imageName = defaultBookImage;

		// 사용자가 사진을 등록한 경우
		if (!bookImage.isEmpty()) {
			String extension = FilenameUtils.getExtension(bookImage.getOriginalFilename());
			imageName = dto.getAuthorName() + "_" + dto.getBookTitle() + "." + extension;
			// 폴더에 파일명을 주고 파일 객체를 생성 -> 0바이트 파일 생성
			File file = new File(imageFolder, imageName);
			// profile의 내용을 file로 이동시키자
			try {
				bookImage.transferTo(file);
			} catch (IllegalStateException | IOException e) {
				e.printStackTrace();
			}
		} else {
			// 사용자가 사진을 등록하지 않은 경우
			File image = new File(imageFolder, defaultBookImage);
			imageName = dto.getAuthorName() + "_" + dto.getBookTitle() + "." + "png";

			if (image.exists()) {
				File file = new File(imageFolder, imageName);
				try {
					Files.copy(image.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

		Book b = dto.toEntity(imageName);
		return bookDao.save(b) == 1;

	}
	
	// 2. 도서 상품 목록 페이지
	public List<BookDto.Recent> get5RecentBooks(Long categoryParent, Long gradeCode, String memberId) {
		Member m = memberDao.findById(memberId);
	    // memberId가 null 또는 빈 문자열인 경우 '0'으로 설정
	    if (m == null) {
	        memberId = "0";
	        // 비회원일 경우 gradeCode를 0으로 설정
	        gradeCode = 0L;
	    } else {
	    	gradeCode = m.getGradeCode();
	    }

	    // DAO를 통해 도서 목록을 가져옵니다.
	    List<BookDto.Recent> recentBooks = bookDao.find5Recent(categoryParent, memberId, gradeCode);

	    // 여기서 책의 포인트 적립금액을 계산할 수 있습니다.
	    for (BookDto.Recent book : recentBooks) {
	        Double pointRate = book.getPointRate(); // 책의 등급별 포인트 적립률
	        Long bookPrice = book.getBookPrice();
	        Double pointEarningsDouble = bookPrice * pointRate;
	        Long pointEarnings = pointEarningsDouble.longValue();
	        book.setPointEarnings(pointEarnings);
	    }

	    return recentBooks;
	}

	
	
	
	
	
	
	
	
	
	
	// 도서별 페이징 리스트 페이지
//	// pageno, 개수 -> prev, start, end, next, pageno, 제품들을 출력한다
//	public Page list(Long pageno) {
//		
//		// 상품 목록의 총 갯수를 센다.
//		Long count = bookDao.count();
//		
//		// pageno의 갯수
//		Long numberOfPage = (count-1)/numberOfProductsPerPage +1;
//		
//		// 사용자가 직접 주소창에 pageno=? 이렇게 쳤을 떄 
//		if(pageno<0) {
//			pageno = -(pageno);
//		} else if(pageno==0) {
//			pageno = 1L;
//		}	else if(pageno>numberOfPage) {
//			pageno=numberOfPage;
//		}
//		
//		// 해당 pageno의 처음 숫자
//		Long startRownum = (pageno-1)*numberOfProductsPerPage +1;
//		
//		// 해당 pageno의 끝 숫자
//		Long endRownum = pageno * numberOfProductsPerPage;
//		
//		// 상품 목록 리스트 ex) startRownum=1 , endRownum=10 이라고 가정하면 bno가 1 부터 10까지의 책 목록 나열
//		List<Book> books =bookDao.findAll(startRownum, endRownum);
//		
//		// 상품의 개수 : 123개
//		//		↓
//		// 페이지의 개수 : 13개
//		
//		// 현재 페이지번호
//		Long start = (pageno-1)/sizeOfPagination * sizeOfPagination + 1;
//		
//		// 이전 버튼
//		Long prev = start -1;
//		
//		// 끝 페이지번호
//		Long end = prev + sizeOfPagination;
//		
//		// 다음 버튼
//		Long next = end +1;
//		
//		// 다음 버튼의 숫자가 페이지 번호의 갯수보다 많거나 끝 페이지 번호보다 많을 경우 다음 버튼은 안보이게 설정
//		if(end>=numberOfPage) {
//			end=numberOfPage;
//			next = 0L;
//			
//		}
//		
//		// pageno	prev	start	end		next
//		// 1~5		 0		  1		 5		  6
//		// 6~10		 5 		  6		 10		 11	
//		// 11~15 	 10		 11 	 13 	 0
//		
//		return new Page(prev,start,end,next,pageno,books);
//	}
//
//	// 상품, 이미지들, 리뷰들, 리뷰 개수, 리뷰 평점 평균을 읽어 출력
//	public ProductDto.Read read(Long pno) {
//		Product p = productDao.findById(pno);
//		if (p == null)
//			return null;
//		List<String> images = imageDao.findByPno(pno);
//		// 사진이 한장도 없다면 default.jpg를 출력
//		if (images.size() == 0)
//			images = Arrays.asList(imageUrl + "default.jpg");
//		List<Review> reviews = reviewDao.findByPno(pno);
//		Long countOfReview = reviewDao.countByPno(pno);
//		Double avgOfReview = reviewDao.avgByPno(pno);
//		return new ProductDto.Read(p.getPno(), p.getVendor(), p.getName(), p.getInfo(), p.getPrice(), countOfReview,
//				avgOfReview, images, reviews);
//	}

//	public void delete(Long pno) {
//		reviewDao.deleteByPno(pno);
//		imageDao.deleteByPno(pno);
//		productDao.deleteById(pno);
//	}
}
