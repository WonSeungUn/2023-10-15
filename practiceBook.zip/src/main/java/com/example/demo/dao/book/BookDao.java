
package com.example.demo.dao.book;

import java.util.*;

import org.apache.ibatis.annotations.*;

import com.example.demo.dto.book.*;
import com.example.demo.entity.book.*;

@Mapper
public interface BookDao {

  // 도서 페이지 (최근 5권의 소설, 참고도서, 만화를 선택해서 리스트 보여주기)
  public List<BookDto.Recent> find5Recent(Long categoryParent, String memberId, Long gradeCode);

  // 셀렉트키 활용
  @SelectKey(statement = "select book_seq.nextval from dual", before = true, resultType = long.class, keyProperty = "bno")
  
  // 책 등록 → 2023/10/11 (원승언 수정) 
  @Insert("INSERT INTO book (bno, category_code, book_title, book_image, book_intro, book_content, publish_date, book_price, stock, translator, publisher_name, author_name) "
      + "VALUES (#{bno}, #{categoryCode}, #{bookTitle}, #{bookImage}, #{bookIntro}, #{bookContent}, #{publishDate}, #{bookPrice}, #{stock}, #{translator}, #{publisherName}, #{authorName})")
  public Integer save(Book book);

  // 페이징을 위한 책 총 갯수 확인
  @Select("select count(*) from book")
  public Long count();

  
  @Select("select * from book where bno=#{bno} and rownum=1")
  public Book findByBook(Long bno);

  // 북 삭제
  @Delete("delete from book where bno=#{bno}")
  public Integer deleteById(Long bno);

  // 장바구니 상품 개수를 증가할 때 재고량을 확인하기 위해 사용한다
  @Select("select stock from book where bno=#{bno} and rownum=1")
  public Integer findStockById(Long bno);
  
//  도서 업데이트
  @Update("update book set book_title=#{bookTitle}, sub_title=#{subTitle}, book_price=#{bookPrice}"
      + ", translator=#{translator} where bno=#{bno}")
  public Integer updateBook(Long bno);

}
