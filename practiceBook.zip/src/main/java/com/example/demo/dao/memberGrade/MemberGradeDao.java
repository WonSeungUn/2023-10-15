package com.example.demo.dao.memberGrade;

import org.apache.ibatis.annotations.*;

@Mapper
public interface MemberGradeDao {
	@Select("select point_rate from member_grade where grade_code=#{gradeCode}")
	public Double findByPointRate(Long gradeCode);
}
