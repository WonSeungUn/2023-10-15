package com.example.demo.entity.orders;

import java.time.*;

import org.springframework.format.annotation.*;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Orders {
	private Long ono;
	private String memberId;
	private Long dno;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate orderDate;
	private Long orderPrice;
	private Long pointEarn;
	private String payment;
	
}