package com.example.demo.service.orderDetails;

import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import com.example.demo.dao.orderDetails.*;
import com.example.demo.entity.orderDetails.*;

@Service
public class OrderDetailsService {
	@Autowired
	private OrderDetailsDao orderDetailsDao;
	
	public List<OrderDetails> list(Long ono) {
		List<OrderDetails> list = orderDetailsDao.findAll(ono);
		return list;
	}
	
		
	
}