package com.example.demo.entity.delivery;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Delivery {
	private Long dno;
	private String memberId;
	private Long zipCode;
	private String receiverName;
	private String deliveryAddress;
	private Long defaultAddress;
	private String receiverTel;
	private String deliveryRequest;
	private String deliveryName;
	
}