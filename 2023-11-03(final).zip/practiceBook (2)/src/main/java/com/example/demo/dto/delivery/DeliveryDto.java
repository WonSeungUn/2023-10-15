package com.example.demo.dto.delivery;

import lombok.*;

@NoArgsConstructor(access=AccessLevel.PRIVATE)
public class DeliveryDto {
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Create {
		private String receiverName;
		private String deliveryName;
		private String receiverTel;
		private Long zipCode;
		private String deliveryAddress;
	}
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Read {
		private Long dno;
		private String receiverName;
		private String addressName;
		private Long defaultAddress;
		private String receiverTel;
		private Long zipCode;
		private String deliveryAddress;
		private String deliveryRequest;
	}
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Update {
		private Long dno;
		private String receiverName;
		private String deliveryName;
		private String receiverTel;
		private Long zipCode;
		private String deliveryAddress;
	}
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Message {
		private Long dno;
		private String deliveryRequest;
	}
}
