package com.example.demo.dto.orders;

import java.util.*;

import com.example.demo.entity.orderDetails.*;

import lombok.*;

@NoArgsConstructor(access=AccessLevel.PRIVATE)
public class OrdersDto {
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	public static class OrdersList {
		private Long ono;
		private String orderDate;
		private String memberId;
		private List<OrderDetails> orderDetails;
	}
	
}

